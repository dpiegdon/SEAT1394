#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>
#include <ctype.h>
#include <poll.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <libraw1394/raw1394.h>

#include "firescope.h"

raw1394handle_t		g_handle;
nodeid_t		g_target;
int			g_target_ok;
u_int64_t		g_target_uid;
int			g_change_occurred;
char*			g_sysmap;
size_t			g_sysmap_size;
int			g_attached;
int			g_machine;
unsigned long		g_init_cpu_mask;
unsigned long		g_xmon_cpu_mask_addr;
unsigned		g_xmon_cpu_mask;
static char		g_local_buf[1024+4];

#define XMON_FW_FLAGS_OUT_ENTERED	0x00000001
#define XMON_FW_FLAGS_OUT_DATA		0x00000002
#define XMON_FW_FLAGS_OUT_ACK		0x00000004
#define XMON_FW_FLAGS_IN_ATTACHED	0x00000001
#define XMON_FW_FLAGS_IN_DATA		0x00000002
#define XMON_FW_FLAGS_IN_ACK		0x00000004
static unsigned long		g_xmon_outbuf_addr;
static unsigned long		g_xmon_outbuf_size_addr;
static unsigned long		g_xmon_iflags_addr;
static unsigned long		g_xmon_oflags_addr;
static unsigned long		g_xmon_idata_addr;
static unsigned long		g_xmon_kick_addr;

static struct termios g_norm_tio;
static struct termios g_raw_tio;

static void
need_console(void)
{
	tcsetattr(STDIN_FILENO, TCSANOW, &g_norm_tio);
}

static void
restore_console(void)
{
	fflush(stdout);
	tcsetattr(STDIN_FILENO, TCSANOW, &g_raw_tio);
}

static int
got_bus_reset(raw1394handle_t hndl, unsigned int generation)
{
	raw1394_update_generation(g_handle, generation);
	g_target_ok = 0;
	g_attached = 0;
	g_change_occurred = 1;
	printf("Bus reset !\n");
}

static int
setup_handle(int port_num)
{
	int port_count;
	struct raw1394_portinfo ports[16];
	
	g_handle = raw1394_new_handle();
	if (!g_handle) {
		perror("libraw1394 couldn't be initialized");
		return -1;
	}

	port_count = raw1394_get_port_info(g_handle, ports, 16);
	if (port_count <= port_num) {
		fprintf(stderr, "Port %d not available (%d ports detected).\n", port_num, port_count);
		return -1;
	}
	raw1394_set_port(g_handle, port_num);
	printf("Port %d (%s) opened, %d nodes detected\n", port_num,
		ports[port_num].name, ports[port_num].nodes);

	raw1394_set_bus_reset_handler(g_handle, got_bus_reset);

	return 0;
}

static void
select_target(void)
{
	int i, tgt, count, local;

	count = raw1394_get_nodecount(g_handle);
	local = raw1394_get_local_id(g_handle) & 0x3f;
	
	need_console();
	printf("%d nodes available, local node is: %d\n", count, local);
	for (i=0; i<count; i++) {
		quadlet_t uuid[2];
		int rc;

		printf(" %d: %04x, uuid: ", i, i | 0xffc0);
		rc = raw1394_read(g_handle, i | 0xffc0, CSR_BASE + 0x40c, 4, &uuid[0]);
		if (rc >= 0)
			rc = raw1394_read(g_handle, i | 0xffc0, CSR_BASE + 0x410, 4, &uuid[1]);
		if (rc < 0)
			printf("<err: %d>", errno);
		else
			printf("%08lx %08lx", uuid[0], uuid[1]);
		if (i == local)
			printf(" [LOCAL]");
		printf("\n");
	}
	printf("pick a target node: ");
	scanf("%d", &tgt);
	if (tgt < 0 || tgt >= raw1394_get_nodecount(g_handle))
		printf("wrong node number !\n");
	else if (tgt == local)
		printf("can't pick local node !\n");
	else {
		g_target = tgt | 0xffc0;
		g_target_ok = 1;
	}
	g_change_occurred = 1;
	restore_console();
}

static void
menu_show(void)
{
	need_console();
	printf("\nFireScope\n---------\n");
	printf("Target : ");
	if (g_target_ok)
		printf("%04x\n", g_target);
	else
		printf("<unspecified>\n");
	printf("Gen    : %d\n", raw1394_get_generation(g_handle));
		
	printf("[Ctrl-T] choose target \n");
	if (g_target_ok) {
		printf("[Ctrl-R] read quad\n");
		printf("[Ctrl-W] write quad\n");
		printf("[Ctrl-A] attach to kernel\n");
	}
	if (g_attached) {
		printf("[Ctrl-O] stop at next timer irq\n");
		printf("[Ctrl-C] catch CPU (reset it)\n");
//		printf("[Ctrl-D] display kernel log");
	}
	printf("[Ctrl-H] this menu\n");
	printf("[Ctrl-Q] quit\n");
	restore_console();
}

static void
read_quadlet(void)
{
	nodeaddr_t addr;
	quadlet_t quad;
	int rc;
	char tmp[128];
	char* p;

	need_console();
	printf("Read from [address]: ");
	scanf("%s", tmp);
	p = tmp;
	addr = 0;
	if (toupper(*p) == 'C') {
		addr = CSR_BASE;
		p++;
	}
	addr += strtoull(p, NULL, 0);
	rc = raw1394_read(g_handle, g_target, addr, 4, &quad);
	if (rc < 0)
		perror("read failed");
	else
		printf("Quadlet at 0x%llx is: 0x%08lx\n", addr, quad);
	restore_console();
}

static void
write_quadlet(void)
{
	nodeaddr_t addr;
	quadlet_t quad;
	int rc;
	char tmp[128];
	char datastr[128];
	char* p;
	
	need_console();
	printf("Write to [address,data]: ");
	scanf("%s %s", tmp, datastr);
	p = tmp;
	addr = 0;
	if (toupper(*p) == 'C') {
		addr = CSR_BASE;
		p++;
	}
	addr += strtoull(p, NULL, 0);
	quad = strtoull(datastr, NULL, 0);
	rc = raw1394_write(g_handle, g_target, addr, 4, &quad);
	if (rc < 0)
		perror("write failed");
	else
		printf("Quadlet at 0x%llx is: 0x%08lx\n", addr, quad);
	restore_console();
}

static unsigned long
__find_symbol(const char* symbol, int *sym_type, int exact)
{
	const char *p, *cur;
	const char *match;
	int goodness = 0;
	int result = 0;
	
	if (!g_sysmap || !g_sysmap_size)
		return 0;

	cur = g_sysmap;
	while(cur) {
		cur = strstr(cur, symbol);
		if (cur) {
			int gd = 1;

			/* best match if equal, better match if
			 * begins with
			 */
			if (cur == g_sysmap || *(cur-1) == ' ') {
				gd++;
				if (cur[strlen(symbol)] == 10)
					gd++;
			}
			if (gd == 3 || (!exact && gd > goodness)) {
				match = cur;
				goodness = gd;
				if (gd == 3)
					break;
			}
			cur++;
		}
	}	
	if (goodness) {
		p = match;
		while(p > g_sysmap && *p != 10)
			p--;
		if (*p == 10) p++;
		result = strtoul(p, (char **)&p, 16);
		if (sym_type) {
			while(*p == ' ')
				p++;
			switch(toupper(*p)) {
				case 'T': *sym_type = sym_text; break;
				case 'D': *sym_type = sym_data; break;
				case 'B': *sym_type = sym_bss; break;
				default:  *sym_type = sym_bad; break;
			}
		}
	}
	return result;
}		

static unsigned long
find_symbol(const char* symbol, int sym_type)
{
	int found_type;
	unsigned long result;
	
	result = __find_symbol(symbol, &found_type, 1);
	if (result && ((found_type & sym_type) == 0))
		result = 0;
	return result;
}

static unsigned long
search_symbol(const char* symbol, int *sym_type)
{
	return __find_symbol(symbol, sym_type, 0);
}

static void
read_xmon_output(void)
{
	unsigned int oflags, i, len;
	
	if (g_xmon_outbuf_addr == 0)
		return;

	rem_writel(virt_to_phys(g_xmon_iflags_addr), XMON_FW_FLAGS_IN_ATTACHED);
	oflags = rem_readl(virt_to_phys(g_xmon_oflags_addr));
	if ((oflags & XMON_FW_FLAGS_OUT_DATA) == 0)
		return;
	len = rem_readl(virt_to_phys(g_xmon_outbuf_size_addr));
	rem_readblk(g_local_buf, virt_to_phys(g_xmon_outbuf_addr), len);
	rem_writel(virt_to_phys(g_xmon_iflags_addr),
		XMON_FW_FLAGS_IN_ATTACHED | XMON_FW_FLAGS_OUT_ACK);
	for (i=0; i<100; i++) {
		oflags = rem_readl(virt_to_phys(g_xmon_oflags_addr));
		if ((oflags & XMON_FW_FLAGS_OUT_DATA) == 0)
			break;
		usleep(1000);
	}
	rem_writel(virt_to_phys(g_xmon_iflags_addr), XMON_FW_FLAGS_IN_ATTACHED);
	if (oflags & XMON_FW_FLAGS_OUT_DATA)
		printf("<timeout reading xmon data>\r\n");
	if (len) {
		char*p = g_local_buf;
		g_local_buf[len] = 0;
		for (i=0; i<len; i++) {
			if (g_local_buf[i] == 10) {
				g_local_buf[i] = 0;
				printf("%s\n\r", p);
				p = &g_local_buf[i+1];
			}
		}
		printf("%s", p);
		fflush(stdout);
		
	}
}
	

static void
send_xmon_key(char key)
{
	unsigned int oflags, i;

	if (!g_xmon_outbuf_addr)
		return;
	oflags = rem_readl(virt_to_phys(g_xmon_oflags_addr));
	if ((oflags & XMON_FW_FLAGS_OUT_ENTERED) == 0)
		return;
	rem_writel(virt_to_phys(g_xmon_idata_addr), (unsigned long)key);
	rem_writel(virt_to_phys(g_xmon_iflags_addr),
		XMON_FW_FLAGS_IN_ATTACHED | XMON_FW_FLAGS_IN_DATA);
	for (i=0; i<1000; i++) {
		oflags = rem_readl(virt_to_phys(g_xmon_oflags_addr));
		if ((oflags & XMON_FW_FLAGS_OUT_ACK) != 0)
			break;
		if ((oflags & XMON_FW_FLAGS_OUT_DATA) != 0) {
			read_xmon_output();
			rem_writel(virt_to_phys(g_xmon_iflags_addr),
				XMON_FW_FLAGS_IN_ATTACHED | XMON_FW_FLAGS_IN_DATA);
			i = 0;
			continue;
		}
		usleep(1000);
	}
	rem_writel(virt_to_phys(g_xmon_iflags_addr), XMON_FW_FLAGS_IN_ATTACHED);
	if ((oflags & XMON_FW_FLAGS_OUT_ACK) == 0)
		goto timeout;
	for (i=0; i<1000; i++) {
		oflags = rem_readl(virt_to_phys(g_xmon_oflags_addr));
		if ((oflags & XMON_FW_FLAGS_OUT_ACK) == 0)
			break;
		usleep(1000);
	}
	if ((oflags & XMON_FW_FLAGS_OUT_ACK) != 0)
		goto timeout;
	return;
timeout:
	printf("<timeout sending xmon data>\r\n");
}

static void
update_remote_data(int initial)
{
	unsigned long cur_mask;
	int i;
	
	if (g_xmon_cpu_mask_addr)
		cur_mask = rem_readl(virt_to_phys(g_xmon_cpu_mask_addr));
	else if (g_xmon_oflags_addr) {
		cur_mask = rem_readl(virt_to_phys(g_xmon_oflags_addr));
		cur_mask &= XMON_FW_FLAGS_OUT_ENTERED;
	} else
		return;
		
	if (cur_mask != g_xmon_cpu_mask) {
		for (i=0; i<NR_CPUS; i++) {
			if ((cur_mask & (1 << i)) && !(g_xmon_cpu_mask & (1 << i)))
				printf("CPU %d %s xmon\r\n", i, initial ? "is in" : "entered");
			else if ((g_xmon_cpu_mask & (1 << i)) && !(cur_mask & (1 << i)))
				printf("CPU %d left xmon\r\n", i);
		}
		g_xmon_cpu_mask = cur_mask;
	}

	read_xmon_output();
}

static void
attach_kernel(void)
{
	unsigned long target_addr;
	
	if (!g_target_ok)
		return;

	g_init_cpu_mask = 0;
	g_xmon_cpu_mask = 0;
	g_attached = 0;
	
	need_console();
	target_addr = find_symbol("_machine", sym_data | sym_bss);
	if (target_addr == 0)
		printf("Can't find _machine in System.map\n");
	else {
		printf("Got _machine at %x, reading %llx...\n",
			target_addr, virt_to_phys(target_addr));
		g_machine = rem_readl(virt_to_phys(target_addr));
		printf("g_machine: %x\n", g_machine);
		switch(g_machine) {
			case 1:
				printf("Found PReP kernel\n"); break;
			case 2:
				printf("Found PMac kernel\n"); break;
			case 4:
				printf("Found CHRP kernel\n"); break;
			default:
				printf("Unrecognized kernel type\n");
				return;
		}
		g_attached = 1;
	}
	if (!g_attached) {
		restore_console();
		return;
	}
	target_addr = find_symbol("cpu_callin_map", sym_data | sym_bss);
	if (target_addr) {
		int i;

		g_xmon_cpu_mask_addr = find_symbol("cpus_in_xmon", sym_data | sym_bss);
		for (i=0; i<NR_CPUS; i++) {
			int enabled = rem_readl(virt_to_phys(target_addr + i*4));
			if (enabled)
				g_init_cpu_mask |= 1 << i;
		}
		printf("Found SMP kernel, CPU mask: %08lx\n", g_init_cpu_mask);
		if (!g_xmon_cpu_mask_addr)
			printf("Kernel don't have xmon compiled in !\n");
	
	} else {
		printf("Kernel appears to be UP\n");
		g_init_cpu_mask = 1;
	}
	g_xmon_outbuf_addr = find_symbol("xmon_fw_outbuf", sym_data | sym_bss);
	if (g_xmon_outbuf_addr) {
		g_xmon_outbuf_size_addr = find_symbol("xmon_fw_outbuf_size", sym_data | sym_bss);
		g_xmon_iflags_addr = find_symbol("xmon_fw_iflags", sym_data | sym_bss);
		g_xmon_oflags_addr = find_symbol("xmon_fw_oflags", sym_data | sym_bss);
		g_xmon_idata_addr = find_symbol("xmon_fw_idata", sym_data | sym_bss);
		g_xmon_kick_addr = find_symbol("xmon_fw_kick", sym_data | sym_bss);
		rem_writel(virt_to_phys(g_xmon_iflags_addr), XMON_FW_FLAGS_IN_ATTACHED);
	}
	restore_console();

	update_remote_data(1);
}

static void
catch_cpu(void)
{
#define KEYLARGO_GPIO_EXTINT_0		0x58
#define KL_GPIO_RESET_CPU0		(KEYLARGO_GPIO_EXTINT_0+0x03)
#define KL_GPIO_RESET_CPU1		(KEYLARGO_GPIO_EXTINT_0+0x04)
#define KL_GPIO_RESET_CPU2		(KEYLARGO_GPIO_EXTINT_0+0x0f)
#define KL_GPIO_RESET_CPU3		(KEYLARGO_GPIO_EXTINT_0+0x10)
#define KL_BASE				0x80000000UL // FIXME
	int cpu_no;
	unsigned long ioaddr;
	unsigned long ioshift;
	unsigned long iomask;
	unsigned long iodata;
	
#if 0
	const int reset_lines[] = {	KL_GPIO_RESET_CPU0,
					KL_GPIO_RESET_CPU1,
					KL_GPIO_RESET_CPU2,
					KL_GPIO_RESET_CPU3 };
	
#endif
	const int reset_lines[] = {	0x71, 0x72, 0x73, 0x74 };
	if (!g_target_ok)
		return;
	need_console();
	printf("(PMac only !) CPU number (0..3) : ");
	scanf("%d", &cpu_no);
	if (cpu_no < 0 || cpu_no > 3) {
		printf("CPU number out of bounds !\n");
		return;
	}
	ioaddr = KL_BASE + reset_lines[cpu_no];
	ioshift = (ioaddr & 0x3) << 3;
	ioaddr &= ~0x3;
	iomask = ~(0xff000000 >> ioshift);
	iodata = rem_readl(ioaddr);
	iodata &= iomask;
	rem_writel(ioaddr, iodata | (0x04000000 >> ioshift));
	usleep(10);
	rem_writel(ioaddr, iodata | (0x00000000 >> ioshift));
	restore_console();
}

static void
break_xmon(void)
{
	rem_writel(virt_to_phys(g_xmon_kick_addr), 1);
}

static void
display_dmesg(void)
{
}

static int
menu_dispatch(char key)
{
	switch(key) {
		case 0x11: /* ctrl-Q */
			return 1;
		case 0x14: /* ctrl-T */
			select_target();
			break;
		case 0x12: /* ctrl-R */
			read_quadlet();
			break;
		case 0x17: /* ctrl-W */
			write_quadlet();
			break;
		case 0x01: /* ctrl-A */
			attach_kernel();
			break;
		case 0x03: /* ctrl-C */
			catch_cpu();
			break;
		case 0x04: /* ctrl-D */
			display_dmesg();
			break;
		case 0x08: /* ctrl-H */
			menu_show();
			break;
	        case 0x0f: /* ctrl-O */
			break_xmon();
			break;
		default:
			if (g_attached)
				send_xmon_key(key);
	}
//	printf("code: %x\n", key);
	return 0;
}

int
main(int argc, char** argv)
{
	char cmd;
	int fd, rc;
	
	if (setup_handle(0) != 0)
		return 0;
	fd = raw1394_get_fd(g_handle);

	if (argc >= 2) {
		int smfd = open(argv[1], O_RDONLY);
		if (smfd < 0)
			printf("Can't load system.map <%>", argv[1]);
		else {
			/* Clean this */
			struct stat stbuf;
			fstat(smfd, &stbuf);
			g_sysmap_size = stbuf.st_size;
			g_sysmap = malloc(g_sysmap_size);
			read(smfd, g_sysmap, g_sysmap_size);
			close(smfd);
			printf("Loaded system.map <%s> <%d> bytes\n", argv[1], g_sysmap_size);
		}
	}
	tcgetattr(STDIN_FILENO, &g_norm_tio);
	memcpy(&g_raw_tio, &g_norm_tio, sizeof(struct termios));
	cfmakeraw(&g_raw_tio);
//	g_raw_tio.c_oflag |= OCRNL;
//	g_raw_tio.c_lflag &= ~ICANON;
	restore_console();

	menu_show();

	do {
		struct pollfd pfds[2];
		char key = 0;
		int loop = 0;

		memset(&pfds, 0, sizeof(pfds));
		pfds[0].fd = STDIN_FILENO;
		pfds[0].events = POLLIN;
		pfds[1].fd = fd;
		pfds[1].events = POLLIN|POLLPRI|POLLERR|POLLHUP;
		rc = poll(pfds, 2, g_attached ? 10 : -1);
		if (rc < 0) {
			rc = errno;
			if (rc != EINTR) {
				printf("poll error %d, exiting...\n", rc);
				goto bail;
			}
		} else if (rc > 0) {
			if (pfds[0].revents != 0)
				read(STDIN_FILENO, &key, 1);
			if (pfds[1].revents != 0)
				loop = 1;
		}
		if (g_attached)
			update_remote_data(0);
		if (loop)
			raw1394_loop_iterate(g_handle);
		if (key && menu_dispatch(key) != 0)
			goto bail;
		if (g_change_occurred) {
			g_change_occurred = 0;
			menu_show();
		}
	} while(1);	

bail:
	tcsetattr(STDIN_FILENO, TCSAFLUSH, &g_norm_tio);
	printf("Exiting...\n");
	raw1394_destroy_handle(g_handle);
}
