#ifndef __FIRESCOPE_H__
#define __FIRESCOPE_H__

#define CSR_BASE	0xfffff0000000ULL
#define NR_CPUS		32
#define KERNELBASE	0xc0000000

enum {
	sym_bad  = 0,
	sym_text = 0x00000001,
	sym_data = 0x00000002,
	sym_bss  = 0x00000004
};

extern raw1394handle_t		g_handle;
extern nodeid_t			g_target;
extern int			g_target_ok;
extern u_int64_t		g_target_uid;
extern int			g_change_occurred;

static inline void rem_writel(nodeaddr_t addr, unsigned long data)
{
	int rc;
	
	if (!g_target_ok)
		return;
	if (addr & 0x3) {
		printf("unaligned rem_writel(%08lx, %08lx)\n", addr, data);
		return;
	}
	rc = raw1394_write(g_handle, g_target, addr, 4, (quadlet_t *)&data);
	if (rc < 0)
		printf("remote write failed, addr=%08lx, data=%08lx", addr, data);
}

static inline unsigned long rem_readl(nodeaddr_t addr)
{
	quadlet_t data = 0xffffffff;
	int rc;
	
	if (!g_target_ok)
		return data;
	if (addr & 0x3) {
		printf("unaligned rem_readl(%08lx)\n", addr);
		return data;
	}
	rc = raw1394_read(g_handle, g_target, addr, 4, &data);
	if (rc < 0)
		printf("remote read failed, addr=%08lx", addr);
	return data;
}

/* Todo: deal with unaligned data */
static inline void rem_readblk(void* dest, nodeaddr_t addr, size_t size)
{
	int i;
	quadlet_t data;
	unsigned long* cdst = (unsigned long*)dest;

	if (!g_target_ok)
		return;
	while(size) {
		data = rem_readl(addr);
		*(cdst++) = data;
		addr += 4;
		size = (size < 4)  ? 0 : (size - 4);
	}
	
}

static inline unsigned long phys_to_virt(nodeaddr_t phys_addr)
{
	return ((phys_addr & 0xffffffffULL) + KERNELBASE);
}

static inline nodeaddr_t virt_to_phys(unsigned long phys_addr)
{
	return (nodeaddr_t)(phys_addr - KERNELBASE);
}

#endif /* __FIRESCOPE_H__ */

