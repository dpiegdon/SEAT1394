""" Python bindings for libraw1394, highlevel interface
Metlstorm 2k6, <metlstorm@storm.net.nz>

Basic usage:

import firewire
host = firewire.Host()
for port in host:
	print port
	for node in port:
		print node
		print node.getConfigROM()

data = host[0].port[0].read(0,64)

import binascii
print binascii.hexlify(data)
"""

import raw1394
import string
import struct
import re
import binascii
import types


# Constant-ish stuff
FIREWIRE_LINKSPEED={0:"S100", 1:"S200", 2:"S400", 3:"Unknown"}
FIREWIRE_CSR_TYPES={0:"Immediate Value", 
					1:"Offset to Immediate Value",
					2:"Offset to Leaf",
					3:"Offset to Directory"}

class FallbackDict(dict):
	def __getitem__(self, key):
		try:
			return dict.__getitem__(self, key)
		except KeyError:
			return "Unknown %s" % key
			
			
FIREWIRE_CSR_ENTRIES=FallbackDict()
FIREWIRE_CSR_ENTRIES[1]="Textual Descriptor"
FIREWIRE_CSR_ENTRIES[2]="Bus Dependant Info"
FIREWIRE_CSR_ENTRIES[3]="Module Vendor ID"
FIREWIRE_CSR_ENTRIES[4]="Module HW Version"
FIREWIRE_CSR_ENTRIES[5]="Module Spec ID"
FIREWIRE_CSR_ENTRIES[6]="Module SW Version"
FIREWIRE_CSR_ENTRIES[7]="Module Dependant Info"
FIREWIRE_CSR_ENTRIES[8]="Node Vendor ID"
FIREWIRE_CSR_ENTRIES[9]="Node HW Version"
FIREWIRE_CSR_ENTRIES[10]="Node Spec ID"
FIREWIRE_CSR_ENTRIES[11]="Node SW Version"
FIREWIRE_CSR_ENTRIES[12]="Node Capabilities"
FIREWIRE_CSR_ENTRIES[13]="Node Unique ID"
FIREWIRE_CSR_ENTRIES[14]="Node Units Extent"
FIREWIRE_CSR_ENTRIES[15]="Node Memory Extent"
FIREWIRE_CSR_ENTRIES[16]="Node Dependant Info"
FIREWIRE_CSR_ENTRIES[17]="Unit Directory"
FIREWIRE_CSR_ENTRIES[18]="Unit Spec ID"
FIREWIRE_CSR_ENTRIES[19]="Unit SW Version"
FIREWIRE_CSR_ENTRIES[20]="Unit Dependant Info"
FIREWIRE_CSR_ENTRIES[21]="Unit Location"
FIREWIRE_CSR_ENTRIES[22]="Unit Poll Mask"
FIREWIRE_CSR_ENTRIES[23]="Model ID"

def FIREWIRE_MAXREC_TO_BYTES(mr):
	return 1 << (mr+1)

def FIREWIRE_OUI_RESOLV(vendor):
	try:
		return FIREWIRE_OUI[vendor]
	except KeyError:
		return ""

OUICONF="oui.txt"
FIREWIRE_OUI = {}


# Exceptions

class OUIResolvMissing(Warning):
	pass

class OUIResolvMalformed(Exception):
	pass

# Misc functions

def init_OUI(fn = OUICONF):
	"""Populates the global FIREWIRE_OUI dictionary with mappings between 24 bit vendor identifier and a text string. Called during module init. 

	Defaults to reading the value of module variable OUICONF.
	The file should have records like
	08-00-8D   (hex)                XYVISION INC.

	Feed it the standard IEEE public OUI file from http://standards.ieee.org/regauth/oui/oui.txt for a more up to date listing.
	"""
	try:
		f = open(fn, "r")
		lines = f.readlines()
		f.close()
		regex = re.compile("(?P<id>([0-9a-fA-F]{2}-){2}[0-9a-fA-F]{2})\s+\(hex\)\s+(?P<name>.*)")
		for l in lines:
			rm = regex.match(l)
			if rm != None:
				textid = rm.groupdict()["id"]
				ouiid = int("0x%s%s%s" % (textid[0:2], textid[3:5], textid[6:8]), 16)
				FIREWIRE_OUI[ouiid] = rm.groupdict()["name"]
		
	except IOError, info:	
		raise OUIResolvMissing("No vendor OUI lookups will be performed: %s" % (OUICONF, info))
	except ValueError:
		raise OUIResolvMalformed("%s malformed" % OUICONF)

def crc16(buf):
	"""Performs a 32bit-wise CRC16 on data in buf, returns crc"""
	crc = 0
	sum = 0
	data = 0
	
	if len(buf) % 4:
		raise ValueError("Length of buf must be divisible by four")

	for i in range(0, len(buf), 4):
		data = struct.unpack("!L", buf[i:i+4])[0]
		#print "CRCing buf[%d:%d] %s (0x%08x)" % (i, i+4, binascii.hexlify(buf[i:i+4]), data)
		for j in range(28, -1, -4):
			sum = ((crc >> 12) ^ (data >> j)) & 0x000fL
			crc = (crc << 4) ^ (sum << 12) ^ (sum << 5) ^ sum 
			crc &= 0xffffffffL
			#print "Iteration: %d Sum: 0x%08x Next: 0x%08x"  % (j, sum, crc)
	

	crc &= 0xffff
	#print "CRC16: 0x%04x" % crc
	
	
	return crc

def checkCRC16(buf, testcrc):
	crc = crc16(buf)
	if testcrc == crc:
		return (True, "Valid")
	else:
		return (False, "Invalid (0x%04x)" % (crc))

# This is really just here cause it's generically useful to anyone writing
# tools that snarf ram
def parseRange(r):
	"""turn the following syntax into a start,end pair:
		start
		start-
		-end	
		start-end
		values are hex if prefixed with 0x, and are 
		kibi, mebi or gibi bytes if suffixed with k,m, or g"""
	
	start = None
	end = None
	
	if len(r) == 0:
		start = 0
	else:
		dc = r.count("-")
		if dc == 0:
			start = parseNum(r)
		elif dc == 1:
			start = parseNum(r.split("-")[0])
			end = parseNum(r.split("-")[1])
			if start == None:
				start = 0
			if end != None:
				if start >= end:
					raise ValueError("Start must be less than end")
		else:
			raise ValueError("Too many hyphens in range")

	return (start,end)

def parseNum(n):
	num = None
	kibi = False
	mibi = False
	gibi = False
	hex = False

	if len(n) == 0:
		pass
	else:
		if len(n) >2:
			if n[0:2] == "0x" or n[0:2] == "0X":
				hex = True
				n = n[2:]

		if len(n) >1:
			if n[-1] not in string.hexdigits:
				if n[-1] == "k" or n[-1] == "K":
					kibi = True
				elif n[-1] == "M" or n[-1] == "m":
					mibi = True
				elif n[-1] == "G" or n[-1] == "g":
					gibi = True

				if kibi or mibi or gibi:
					n = n[:-1]
		if len(n):
			if hex:
				num = long(n,16)
			else:
				num = long(n)
				
			if kibi:
				num <<= 10
			elif mibi:
				num <<= 20
			elif gibi:
				num <<= 30
		
	return num
# Classes

class Raw1394Handle:
	"""Wrapper class around a handle from the raw1394 module, which provides the interface to /dev/raw1394.

	Managed automatically by the Host class."""
	def __init__(self, port=None):
		self.port = port
		self.h = None
		self.h = raw1394.raw1394_py_new_handle()
		if self.port != None:
			raw1394.raw1394_py_set_port(self.h, port)
		
	def __del__(self):
		"""Clean up our handle"""
		if self.h != None:
			raw1394.raw1394_destroy_handle(self.h)
			self.h = None

class Host:
	"""Basic interface to Firewire devices, encapsulating a Firewire enabled host (ie, the machine where this runs.)

	Hosts have ports (physical Firewire connectors), ports have nodes (devices).
	Supports container style access to it's ports, so 
		host = Host()
		for port in host:
			print host
	will enumerate the ports available, and 
		host[0]
		host[1]
		...
	can be used for individual ports.

	May throw an exception during init if it is unable to open the /dev/raw1394 device for read-write.
	"""
	def __init__(self):
		self.handle = Raw1394Handle()
		self.ports = []
		self.initPorts()
	
	def __len__(self):
		return len(self.ports)
	
	def __getitem__(self, key):
		return self.ports[key]
	
	def initPorts(self):
		pi = raw1394.raw1394_py_get_port_info(self.handle.h)
		for i in range(len(pi)):
			port = Port()
			port.fromPortinfo(i, pi[i])
			self.ports.append(port)
	
	
	def __str__(self):
		return "Host(ports=%d)" % len(self.ports)

class Port:
	"""Provides access to an individual firewire interface on a host.

	Ports have one or more nodes attached (the local system counts as a node) which may be grouped into one or more bus. 

	Supports container style access to it's nodes, so 
		host = Host()
		port = host[0]
		for node in port:
			print node
	will enumerate the nodes available, and 
		port[0]
		port[1]
		...
	can be used for individual nodes.

	Note that the node index number directly correlates to the firewire node address, and hence may change when devices are plugged in. Node objects are only valid for a given bus generation, which may be incremented at any time. 

	Support for registering a bus-reset callback is unimplemented at this time.
	"""
	def __init__(self):
		self.name = None
		self.h = None
		self.nodeid_cache = None

	def __len__(self):
		return self.getNodeCount()
	
	def __getitem__(self, key):
		if not isinstance(key,int):
			raise TypeError("Index must be an integer")
		if key < 0 or key > self.getNodeCount():
			raise IndexError
			
		nodes = self.getNodes()
		return nodes[key]
	
	def getNodes(self):
		"""Retrieves a list of nodes on the bus"""
		nodes=[]
		for i in range(self.getNodeCount()):
			nodes.append(Node(self, i))
		return nodes

	def getNodeCount(self):
		"""Returns the number of nodes on the bus, including ourselves."""
		if self.h != None:
			return raw1394.raw1394_get_nodecount(self.h.h)
		else:
			return None
	
	def getBusID(self):
		"""Returns the bus address of this host's node"""
		if self.h != None:
			if self.nodeid_cache == None:
				v = raw1394.raw1394_py_get_local_id(self.h.h)
				self.nodeid_cache =  (int(v) & 0xffc0) >> 6

			return self.nodeid_cache
		else:
			return None
	
	def getLocalID(self):
		"""Returns the address of this host's node"""
		if self.h != None:
			v = raw1394.raw1394_py_get_local_id(self.h.h)
			return int(v) & 0x3f
		else:
			return None
	
	def getGeneration(self):
		"""Returns the current bus generation count, which is incremented every time a device is added or removed"""
		if self.h != None:
			return int(raw1394.raw1394_get_generation(self.h.h))  
		else:
			return None
		
			
	def fromPortinfo(self, idx, pi):
		"""Populates self from a libraw1394 portinfo struct, used internall by Host to build ports"""
		self.portno = idx
		try:
			self.name = pi.name[:pi.name.index("\x00")]
		except ValueError:
			self.name = pi.name
		self.h = Raw1394Handle(self.portno)

	def getConfigRom(self):
		rom, ver = raw1394.raw1394_py_get_config_rom(self.h.h)
		return rom, ver

	def setConfigRom(self, romimage):
		rom, ver = self.getConfigRom()
		if isinstance(romimage, types.StringType):
			romimage = buffer(romimage)
		raw1394.raw1394_py_update_config_rom(self.h.h, romimage, ver)
	
	def resetBus(self):
		raw1394.raw1394_reset_bus(self.h.h)
	
	def __str__(self):
		return "Port(number=%d, generation=%d, busid=%d, localid=%d, nodeCount=%d, name='%s')" % (self.portno, self.getGeneration(), self.getBusID(), self.getLocalID(), self.getNodeCount(), self.name)
	
class Bus:
	def __init__(self, busid=0):
		pass

def configEntry(node, depth, addr):
	"""Factory function that returns a instance of one of ConfigEntry's subclasses, based on the entry type"""
	ce = ConfigEntry(node, depth, addr)
	ce.readEntry()
	if ce.keytype == 0:
		ces = ConfigEntryImmediate(node, depth, addr, ce.keytype, ce.keyvalue, ce.data)
	elif ce.keytype == 1:
		ces = ConfigEntryOffsetImmediate(node, depth, addr, ce.keytype, ce.keyvalue, ce.data)
	elif ce.keytype == 2:
		ces = ConfigEntryOffsetLeaf(node, depth, addr, ce.keytype, ce.keyvalue, ce.data)
	elif ce.keytype == 3:
		ces = ConfigEntryOffsetDir(node, depth, addr, ce.keytype, ce.keyvalue, ce.data)
	else:
		# Not that this can happen; it's a 4 bit value...
		raise ValueError("Unhandled Keytype %d" % ce.keytype)
		
	return ces

class ConfigEntry:
	"""Base class for an ISO/IEC 13213 Config Status Regsister entry.

	This is pieced together from various other implementations and public docs, because the actual standard isn't available without paying US$90 for it. Bah!
	"""
	def __init__(self, node, depth, addr, keytype=None, keyvalue=None, data =None):
		self.node = node
		self.addr = addr
		self.depth = depth
		self.keytype = keytype
		self.keyvalue= keyvalue
		self.data = data
	
	def readEntry(self):
		data = self.node.read(self.addr,4)
		key, v1, v2, v3 = struct.unpack("BBBB", data)
		self.keytype = (key & 0xc0) >> 6
		self.keyvalue = key & 0x3f
		self.data = (v1 << 16) + (v2 << 8) + v3
	
	def readRaw(self):
		return self.node.read(self.addr, 4)
	
	def __str__(self):
		return "%s%d (%s), %d (%s)" % (" " * (self.depth), self.keytype, FIREWIRE_CSR_TYPES[self.keytype], self.keyvalue, FIREWIRE_CSR_ENTRIES[self.keyvalue])

class ConfigEntryImmediate(ConfigEntry):
	"""Config Entry which takes a simple 24bit integer"""
	def __str__(self):
		extra = ""
		if self.keyvalue in [3,5,8,10,18]:
			extra = " (%s)" % FIREWIRE_OUI_RESOLV(self.data)
		return ConfigEntry.__str__(self) + ": 0x%x%s" % (self.data, extra)

class ConfigEntryOffsetImmediate(ConfigEntry):
	"""Config Entry which reads an integer from an offset
	
	Currently doesn't actually retrieve the data, because it doesn't work on any of my devices - they give bogus offsets.
	"""
	def __init__(self, node, depth, addr, keytype=None, keyvalue=None, data =None):
		ConfigEntry.__init__(self, node, depth, addr, keytype, keyvalue, data)
		self.offsetdata = 0 
		# TODO: Fix me - on my ipod, data is 0x4000, and reading self.addr+ data * 4 
		# blows up with Errno 22, Invalid Argument :/
		if ((self.data * 4)+ self.addr) > (long(raw1394.CSR_REGISTER_BASE) + raw1394.CSR_CONFIG_ROM_END):
			self.text="**Offset to immediate beyond end of CSR space**"
		else:
			d = self.node.read(self.addr + (self.data * 4),4)
			self.offsetdata = struct.unpack("!L", d)[0]
	
	def __str__(self):
		if hasattr(self, "text"):
			text = self.text
		else:
			text = "0x%08x" % self.offsetdata
			
		s=ConfigEntry.__str__(self) + ": Offset: %d bytes Offset Data: %s" % (self.data * 4, text)
		return s
	pass

class ConfigEntryOffsetLeaf(ConfigEntry):
	"""Config entry which reads a text leaf from an offset"""
	def __init__(self, node, depth, addr, keytype=None, keyvalue=None, data =None):
		ConfigEntry.__init__(self, node, depth, addr, keytype, keyvalue, data)
		self.leaf = ConfigLeaf(self.node, self.depth + 1, self.addr + (self.data * 4))
	
	def __str__(self):
		s=ConfigEntry.__str__(self) + ": Offset: %d bytes" % (self.data * 4)
		s+= "\n%s" % (self.leaf)
		return s
	
class ConfigEntryOffsetDir(ConfigEntry):
	"""Config entry that reads a directory from an offset, and recurses"""
	def __init__(self, node, depth, addr, keytype=None, keyvalue=None, data =None):
		ConfigEntry.__init__(self, node, depth, addr, keytype, keyvalue, data)
		self.dir = ConfigDir(self.node, self.depth + 1, self.addr + (self.data * 4), FIREWIRE_CSR_ENTRIES[self.keyvalue] )
	
	def __str__(self):
		s=ConfigEntry.__str__(self) + ": Offset: %d bytes" % (self.data * 4)
		s+= "\n %s" % (self.dir)
		return s
	pass

class ConfigLeaf:
	"""Config Leaf node, which has strings attached.
	
	Uh, without the actual spec, I dont know if there are other types of leaves than a 'textual descriptor'. Suck."""
	def __init__(self, node, depth, addr):
		self.node = node
		self.depth = depth
		self.addr = addr
		self.len = 0
		self.crc = 0
		self.spec = None
		self.lang = None
		self.text = ""
		self.rawdata = "" # Used to accumulate data for crc validation
		self.readLeaf()
	
	def readLeaf(self):
		self.rawdata = ""
		offset = self.addr
		data = self.node.read(offset,4)
		self.len, self.crc = struct.unpack("!HH", data)
		offset += 4
		data = self.node.read(offset,4)
		self.rawdata += data
		self.spec = struct.unpack("!L", data)[0]
		offset += 4
		data = self.node.read(offset,4)
		self.rawdata += data
		self.lang = struct.unpack("!L", data)[0]
		# Sanity check the leaf
		if ((self.len * 4)+ self.addr) > (long(raw1394.CSR_REGISTER_BASE) + raw1394.CSR_CONFIG_ROM_END):
			self.text="**Offset to leaf beyond end of CSR space**"
		else:
			for i in range(8, self.len * 4, 4):
				data = self.node.read(self.addr + i + 4,4)
				self.rawdata += data
				self.text+= string.join(struct.unpack("cccc", data), "")
	
	def readRaw(self):
		return self.rawdata
			
	def __str__(self):
		return "%sTextLeaf: %d bytes, crc: 0x%04x (%s), language spec: 0x%08x (%s), language id: 0x%08x,\n%stext: \"%s\"" % (" " * (self.depth),self.len * 4, self.crc, checkCRC16(self.rawdata, self.crc)[1], self.spec, FIREWIRE_OUI_RESOLV(self.spec), self.lang, " " * (self.depth), self.text)
		

class ConfigDir:
	"""Implements an ISO/IEC 13213 Config Status Regsister Directory
	"""
	def __init__(self, node, depth, addr, type="Root Directory"):
		self.node = node
		self.addr = addr
		self.length = 0
		self.crc = 0
		self.depth = depth
		self.type = type
		self.entries=[]
		self.rawdata = "" # Used to accumulate data for crc validation

		self.readDirectory(addr)
	
	def readRaw(self):
		data = self.rawdata
		for e in self.entries:
			print "ConfigDir: raw entry depth %d 0x%s" % (e.depth, binascii.hexlify(e.readRaw()))
			data += e.readRaw()
		return data
	
	def readDirectory(self, addr):		
		self.rawdata = ""
		data = self.node.read(addr,4)
		self.length, self.crc = struct.unpack("!HH", data)
		addr+=4
		#print "Blocklen: %d" % blocklen
		for i in range(0, self.length * 4, 4):
			self.rawdata += self.node.read(addr+i, 4)
			self.entries.append(configEntry(self.node, self.depth + 1, addr +i))

	def __str__(self):
		s = "%s%s: %d bytes, crc: 0x%04x (%s)" % (" " * (self.depth),  self.type, self.length *4, self.crc, checkCRC16(self.rawdata, self.crc)[1])
		for e in self.entries:
			s += "\n%s" % (e)
		return s

class ConfigROM:
	"""Implements an ISO/IEC 13213 Config Status Regsister. 
	
	Firewire devices expose their configuration via this ConfigROM. The type of device, it's speed, options, parameters and other vendor specific data is available.

	Note that no checksum validation is actually performed yet.
	"""
	def __init__(self, node = None):
		self.info_len = None
		self.crc_len = None
		self.crc = None
		self.busid = None
		self.max_rec = None # Maximum record size in quads
		self.link_speed = None # Link speed table index
		self.guid = None 
		self.irmc = None 	# Isocronous Resource MAnager capable
		self.cmc = None 	# Cycle manager capable
		self.isoc = None 	# Isocronous capable
		self.bmc = None		# Bus master capable
		self.cmca = 0 		# Cycle master timing accuracy
		self.rawdata = "" # Used to accumulate data for crc validation
		
		self.node=node
		if node != None:
			self.fromNode(node)
	
	def maxBytes(self):
		return FIREWIRE_MAXREC_TO_BYTES(self.max_rec)
	
	def readRaw(self):
		#This is broken, and not fixable without re-architecting the whole CSR-thing
		raise UnimplementedError
		data = self.rawdata
		data += self.rootdir.readRaw()
		return data

	def fromNode(self, node):
		"""Populates the config rom from a given node, called by __init__ if node != None"""
		self.node=node
		self.rawdata = ""
		offset = long(raw1394.CSR_REGISTER_BASE) + raw1394.CSR_CONFIG_ROM
		data = self.node.read(offset, 4)	
		# Read Config ROM Header
		self.info_len, self.crc_len, self.crc = struct.unpack("!BBH", data)
		# Read extended ROM
		if self.info_len >1:
			offset+=4
			# Read Bus ID Magic
			data = self.node.read(offset, 4)	
			self.rawdata += data
			self.busid = string.join(struct.unpack("cccc", data), "")
			# Read Bus Options Register
			offset+=4
			data = self.node.read(offset, 4)	
			self.rawdata += data
			byte1, byte2, self.max_rec, self.link_speed = struct.unpack("BBBB", data)
			self.max_rec = self.max_rec >> 4
			self.link_speed &= 0x7
			self.irmc = (byte1 & 0x80) >> 7 
			self.cmc = (byte1 & 0x40) >> 6
			self.isoc = (byte1 & 0x20) >> 5
			self.bmc = (byte1 & 0x10) >> 4
			if self.cmc:
				self.cmca = int(byte2)
			# Read GUID
			offset+=4
			data = self.node.read(offset, 4)	
			self.rawdata += data
			offset+=4
			data2 = self.node.read(offset, 4)	
			self.rawdata += data2
			self.guid = struct.unpack("!L", data)[0]
			self.guid = self.guid << 32
			self.guid += struct.unpack("!L", data2)[0]
			self.vendor = (self.guid & 0xffffff0000000000) >> 40 
			
			# Read directories
			offset+=4
			self.rootdir = ConfigDir(node, 1, offset)
	
	def __str__(self):
		s =  "ConfigROM("
		s += "\n Length                               : %d bytes" % (self.info_len * 4)
		s += "\n CRC Length                           : %d bytes" % (self.crc_len * 4)
		s += "\n CRC                                  : 0x%04x (%s)" % (self.crc, checkCRC16(self.rawdata, self.crc)[1])
		try:
			s += "\n Bus ID                               : \"%s\"" % self.busid
			s += "\n GUID                                 : 0x%016x" % self.guid
			s += "\n Vendor                               : 0x%08x (%s)" % (self.vendor, FIREWIRE_OUI_RESOLV(self.vendor))
			s += "\n Link Speed                           : %d (%s)" % (self.link_speed, FIREWIRE_LINKSPEED[self.link_speed])
			s += "\n Max Record Size                      : %d (%d bytes)" % (self.max_rec, FIREWIRE_MAXREC_TO_BYTES(self.max_rec))
			s += "\n Isochronous Capable                  : %d (%s)" % (self.isoc, self.isoc and "Yes" or "No")
			s += "\n Bus Master Capable                   : %d (%s)" % (self.bmc, self.bmc and "Yes" or "No")
			s += "\n Cycle Master Capable                 : %d (%s)" % (self.cmc, self.cmc and "Yes" or "No")
			s += "\n Cycle Master Clock Accuracy          : %d ppm" % (self.cmca)
			s += "\n Isochronous Resource Manager Capable : %d (%s)" % (self.irmc, self.irmc and "Yes" or "No")
			s+="\n%s" % self.rootdir
		except TypeError:
			pass

		s += "\n)"
		return s


class Node:
	"""Encapsulates a single device on a bus connected to a port on a host.
	"""
	def __init__(self, port, number):
		self.port = port
		self.number = number
		self.rom = ConfigROM(self)
	
	def getConfigROM(self):
		"""Returns the device's configuration ROM"""
		return self.rom
	
	def getNodeID(self):
		"""Returns the address of the node on the bus"""
		return int((self.port.getBusID() << 6) + self.number)
	
	def read(self, addr, bytes):
		"""Reads bytes from address on the node, returns a string.

		If a node doesn't feel like fulfilling a request, it will raise an IOError. 

		If the number of bytes is greater than the maximum record size, multiple reads will be performed. Note that some areas of the address space are not guaranteed to be meaningful if reads are not quad aligned, or single quads in length. This normally applies to the CSR space (0xfffff0000000 upwards). Other areas of address space may not be mapped on the node, and reading them may cause the node to crash. :)
		"""
		
		data = ""
		try:
			# TODO: Fix this to poll us and endpoint for minimum maxbytes
			maxb = self.rom.maxBytes()
			raise AttributeError
		except AttributeError:
			maxb = 512
			

		if bytes < maxb:
			maxb = bytes

		for i in range(0, bytes, maxb):
			addrhi = addr + i & 0x0000ffff00000000L
			addrhi = addrhi >> 32
			addrlo = addr + i & 0x00000000ffffffffL
				
			data +=str(raw1394.raw1394_py_read(self.port.h.h, self.getNodeID(), long(addrhi), long(addrlo), maxb))
			
		return data

	def write(self, addr, data):
		"""Writes contents of buffer data to address on the node.

		If a node doesn't feel like fulfilling a request, it will raise an IOError. 

		If the length of data is greater than the maximum record size, multiple writes will be performed. 

		Note that writing to a node's memory willy nilly is likely to cause crashes, or, uh, worse.
		"""
		
		try:
			# TODO: Fix this to poll us and endpoint for minimum maxbytes
			raise AttributeError
			maxb = self.rom.maxBytes()
		except AttributeError:
			maxb = 512
			

		if len(data) < maxb:
			maxb = len(data)

		for i in range(0, len(data), maxb):
			addrhi = addr + i & 0x0000ffff00000000L
			addrhi = addrhi >> 32
			addrlo = addr + i & 0x00000000ffffffffL
			raw1394.raw1394_py_write(self.port.h.h, self.getNodeID(), long(addrhi), long(addrlo), maxb, data[i:i+maxb])
			
	def __str__(self):
		return "Node(number=%d, nodeid=0x%04x)" % (self.number, self.getNodeID())


init_OUI()
